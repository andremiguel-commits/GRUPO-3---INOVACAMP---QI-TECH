#ifndef BLOCKCHAIN_H
#define BLOCKCHAIN_H
#include "Bloco.h"
#include <string>

using namespace std;

class Blockchain {
private:
    int tamanho;
public:
    int indice;
    Bloco** blocos;
    
    Blockchain(Bloco* BlocoGenesis);
    virtual ~Blockchain();
    void adicionarBloco(Bloco* bloco);
    Bloco* search(string identificacao);
    
};

#endif