#ifndef BLOCO_H
#define BLOCO_H

#include <string>
#include <iostream>

using namespace std;

class Bloco {
private:
    string recipiente, emissor;
    double valor;
    string identificacao;
    string chave;

    string hash();
    string converteValorEmTexto(double valor);
    char converteNumeroEmLetra(int n);

public:
    Bloco* proximo;
    Bloco* anterior;

    Bloco(string recipiente, string emissor, double valor);
    string getIdentificacao();
    virtual ~Bloco();
};

#endif