#include "Blockchain.h"
#include "Bloco.h"

Blockchain::Blockchain(Bloco* BlocoGenesis){
    this->tamanho = 10;
    this->indice = 0;
    
    blocos = new Bloco*[tamanho];
    blocos[0] = BlocoGenesis;
}

Blockchain::~Blockchain(){
    for(int i = 0; i < tamanho - 1; i++) {
        delete blocos[i];
    }
    delete[] blocos;
}

void Blockchain::adicionarBloco(Bloco* bloco){
    indice++;
    blocos[indice] = bloco;
    if(indice <= 9) {
        this->blocos[indice]->anterior = this->blocos[indice - 1];
        this->blocos[indice - 1]->proximo = this->blocos[indice];
    }
}

Bloco* Blockchain::search(string identificacao) {
    for(int i = 0; i < (tamanho - 1); i++) if (this->blocos[i]->getIdentificacao() == identificacao) return this->blocos[i];
    return nullptr;
}