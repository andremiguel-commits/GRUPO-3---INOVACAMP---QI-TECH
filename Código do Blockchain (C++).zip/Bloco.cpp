#include "Bloco.h"
#include <cmath>
#include <cctype>
#include <iostream>

Bloco::Bloco(string recipiente, string emissor, double valor) {
    this->recipiente = recipiente;
    this->emissor = emissor;
    this->valor = valor;
    this->proximo = nullptr;
    this->anterior = nullptr;
    this->chave = "anfqi";

    this->identificacao = this->hash();
}

Bloco::~Bloco(){

}

string Bloco::getIdentificacao(){
    return this->identificacao;
}

string Bloco::converteValorEmTexto(double valor) {
    int numero = floor(valor);
    int resto;
    char letra;
    string resultado = "";

    while (numero > 0) {
        resto = (numero%100)%26;
        letra = 'a' + resto;
        resultado += letra;
        numero /= 100;
    }

    return resultado;
}

char Bloco::converteNumeroEmLetra(int n) {
    //baseado na expressao algebrica que  define a cifra de vigenere
    if(n%26 == 0) return 'a';
    else return ('a' + n%26);
}

string Bloco::hash() {
    /*cifra de vigenere*/
    string concatenado;
    string textoCifraIncompleto = "";
    string textoCifraCompleto = "";
    string emissorConvertido = "";
    string recipienteConvertido = "";
    int resto;

    // conversao de dados para strings em letras minusculas
    string valorConvertido = converteValorEmTexto(this->valor);
    cout << valorConvertido << endl;

    for(char c : this->emissor) {
        emissorConvertido += tolower(c);
    }
    cout << emissorConvertido << endl;

    for(char c : this->recipiente) {
        recipienteConvertido += tolower(c);
    }
    cout << recipienteConvertido << endl;

    //geracao de um identificador que vai ser criptografado
    concatenado =  valorConvertido + recipienteConvertido + emissorConvertido;
    cout << concatenado << endl;

    //criacao de uma variavel de mesmo tamanho que 'concatenado' com as letras da chave
    for(int i = 0; i < concatenado.length(); i++) {
        resto = i%3;
        cout << resto << " " << i << endl;
        switch (resto)
        {
        case 0:
            textoCifraIncompleto += 'a';
            break;
        case 1:
            textoCifraIncompleto += 'f';
            break;
        case 2:
            textoCifraIncompleto += 'n';
            break;
        case 3:
            textoCifraIncompleto += 'q';
            break;
        case 4:
            textoCifraIncompleto += 'i';
            break;
        default:
            break;
        }
    }
    //textoCifraIncompleto += 'd';
    cout << textoCifraIncompleto << endl;
    
    //geracao do texto criptografado
    for(int i = 0; i < (concatenado.length()); i++) {
        textoCifraCompleto += converteNumeroEmLetra(textoCifraIncompleto.at(i) + concatenado.at(i) - 194);
        cout << i << " " << textoCifraCompleto << endl;
    }
    return textoCifraCompleto;
}
