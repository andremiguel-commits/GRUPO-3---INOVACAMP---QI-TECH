#include "Blockchain.h"
#include "Bloco.h"
#include <iostream>

using namespace std;

int main() {
    Bloco* b1 = new Bloco("Felipe", "Andre", 1000);
    //Bloco* b2 = new Bloco("Felipe", "Andre", 250);

    cout << b1->getIdentificacao() << endl;
    delete b1;
    
    
    //cout << 'a' + n << endl;
    
}